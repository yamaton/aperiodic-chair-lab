# Recut-chair review package

Open START_HERE.html or review-brief.pdf. The HTML uses native MathML and
has no external assets. Original source paths are preserved.

To reproduce the four primary checks and two periodic controls:

```sh
uv run --locked python strong/review/verify_package.py
```

Python 3.13+ and uv are needed; dependencies may download on first use.
The runner checks the file manifest, then works in a temporary copy.
Use --hashes-only to verify the archive without running calculations.

The defining solid is strong/audit/frozen_v1/candidate.json. The viewer and
STL are illustrations. The archived proposal preserves its original bytes
and historical proper-copy scope; its relative links use strong/ as base.
Current scope and reflection/grouping extensions are stated in the brief.

The preparation run is recorded in strong/artifacts/review_reproduction.json.
It reports six successful checks; it does not establish the written global
geometry arguments. The source archive contains a checksum manifest for
every supplied file except the manifest itself.

This is an AI-assisted research proposal requiring mathematical review.
No external endorsement or novelty determination is claimed.
